package com.juint2;

import java.util.Scanner;

import org.junit.Test;


public class Code1Test {
	/**
	 * 各变量分别取略小于最小值、最小值、略大于最小值
	 * 正常值、略小于最大值、最大值和略大于最大值，所以
	 * A,B,C分别取值为:-1、0、1、5000、9998、9999/10000。
	 */
	/**
	 * 测试用例
	 * 序号	第一个数a第二个数b  第三个数c	    预期结果	     测试结果	备注
	 * 1	0	    3000	   6000	           最大值为6000	6000   a取极值
	   2	1	    3000	  6000	           最大值为6000	 6000
       3	9999	3000	  6000	           最大值为9999	 9999
       4	9998	3000	  6000	            最大值为9998	 9998
       5	3000	0	      6000	             最大值为6000	  6000	b取极值
       6	3000	1	      6000	             最大值为6000	 6000	
	   7	3000	9999	  6000	            最大值为9999	 9999
       8	3000	9998	  6000	           最大值为9998	 9998
       9	3000	6000	  0	                  最大值为6000	 6000	 c取极值
       10	3000	6000	  1	                  最大值为6000	 6000
       11	3000	6000	  9999	          最大值为9999	 9999
       12	3000	6000	  9998	          最大值为9998	 9998
       13	3000	6000	  5000	         最大值为6000	 6000	a,b,c皆为正常值
       14	3000	6000	  10000	     输入数据非法(无效)
	 */
	@Test
	public void testCode1(){
		Code1 c=new Code1();
		c.test();
	}	
	 public static void test2() {
	        int a,b,c;	         
	        Scanner scan = new Scanner(System.in);
	        System.out.println("请输入三个数:");
	        //键盘输入三个数
	        a = scan.nextInt();
	        b = scan.nextInt();
	        c = scan.nextInt();
	        if(a<0||a>9999) {
	        	System.out.println("a输入数据非法(无效)");
	        	return;
	        }
	        if(b<0||b>9999) {
	        	System.out.println("b输入数据非法(无效)");
	        	return;
	        }
	        if(c<0||c>9999) {
	        	System.out.println("c输入数据非法(无效)");
	        	return;
	        }
	        System.out.println("最大值为：" + getMax(c, getMax(a, b)));	         
	    }
	    //比较方法
	    private static int getMax(int x,int y){
	        return x > y ? x : y;
	    }	
}
