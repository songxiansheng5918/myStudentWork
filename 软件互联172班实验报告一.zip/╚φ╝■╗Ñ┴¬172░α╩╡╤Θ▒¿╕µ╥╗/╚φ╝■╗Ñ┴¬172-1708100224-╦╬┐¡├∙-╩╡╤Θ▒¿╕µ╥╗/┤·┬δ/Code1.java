package com.juint2;

import java.util.Scanner;

public class Code1 {
	 	public static void test() {
	        int a,b,c;	         
	        Scanner scan = new Scanner(System.in);
	        System.out.println("请输入三个数:");
	        //键盘输入三个数
	        a = scan.nextInt();
	        b = scan.nextInt();
	        c = scan.nextInt();
	        if(a<0||a>9999) {
	        	System.out.println("a输入数据非法(无效)");
	        	return;
	        }
	        if(b<0||b>9999) {
	        	System.out.println("b输入数据非法(无效)");
	        	return;
	        }
	        if(c<0||c>9999) {
	        	System.out.println("c输入数据非法(无效)");
	        	return;
	        }
	        System.out.println("最大值为：" + getMax(c, getMax(a, b)));	         
	    }
	    //比较方法
	    private static int getMax(int x,int y){
	        return x > y ? x : y;
	    }
}